export interface Token {
  access: string;
  refresh: string;
}


