import { Component } from '@angular/core';

@Component({
  selector: 'app-dealer-item',
  standalone: true,
  imports: [],
  templateUrl: './dealer-item.component.html',
  styleUrl: './dealer-item.component.css'
})
export class DealerItemComponent {

}
