export interface User{
  id: number,
  user: string,
  image: string
}
