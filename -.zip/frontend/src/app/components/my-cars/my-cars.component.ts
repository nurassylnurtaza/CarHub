import { Component } from '@angular/core';

@Component({
  selector: 'app-my-cars',
  standalone: true,
  imports: [],
  templateUrl: './my-cars.component.html',
  styleUrl: './my-cars.component.css'
})
export class MyCarsComponent {

}
