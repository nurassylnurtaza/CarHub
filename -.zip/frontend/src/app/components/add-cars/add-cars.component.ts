import { Component } from '@angular/core';

@Component({
  selector: 'app-add-cars',
  standalone: true,
  imports: [],
  templateUrl: './add-cars.component.html',
  styleUrl: './add-cars.component.css'
})
export class AddCarsComponent {

}
