import { Component } from '@angular/core';

@Component({
  selector: 'app-dealers',
  standalone: true,
  imports: [],
  templateUrl: './dealers.component.html',
  styleUrl: './dealers.component.css'
})
export class DealersComponent {

}
